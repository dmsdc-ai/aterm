#!/usr/bin/env node
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url);

const PLATFORM_PACKAGES = {
  darwin: {
    arm64: '@dmsdc-ai/aterm-darwin-arm64',
  },
};

function resolvePlatformPackage() {
  return PLATFORM_PACKAGES[os.platform()]?.[os.arch()] ?? null;
}

const platformPackage = resolvePlatformPackage();
if (!platformPackage) {
  console.warn(`[aterm] no native package for ${os.platform()} ${os.arch()}; install skipped`);
  process.exit(0);
}

let platformPackageJsonPath;
try {
  platformPackageJsonPath = require.resolve(`${platformPackage}/package.json`);
} catch (error) {
  console.warn(`[aterm] optional native package not installed: ${platformPackage}`);
  console.warn('[aterm] reinstall after the platform package is available');
  process.exit(0);
}

const platformRoot = path.dirname(platformPackageJsonPath);
const sourceApp = path.join(platformRoot, 'dist', 'aterm.app');
const targetApp = path.join(__dirname, 'dist', 'aterm.app');

if (!fs.existsSync(sourceApp)) {
  console.error(`[aterm] native app bundle missing from ${platformPackage}: ${sourceApp}`);
  process.exit(1);
}

fs.rmSync(path.dirname(targetApp), { recursive: true, force: true });
fs.mkdirSync(path.dirname(targetApp), { recursive: true });
fs.cpSync(sourceApp, targetApp, { recursive: true });

console.log(`[aterm] installed native bundle from ${platformPackage}`);
