#!/usr/bin/env node
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url);
const packageJson = JSON.parse(
  fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8'),
);

const PLATFORM_PACKAGES = {
  darwin: {
    arm64: '@dmsdc-ai/aterm-darwin-arm64',
  },
};

function resolvePlatformPackage() {
  return PLATFORM_PACKAGES[os.platform()]?.[os.arch()] ?? null;
}

function bootstrapEcosystem() {
  const homeDir = os.homedir();
  const directories = [
    path.join(homeDir, '.aigentry', 'inbox'),
    path.join(homeDir, '.aigentry', 'config'),
    path.join(homeDir, '.aigentry', 'brain', 'local'),
    path.join(homeDir, '.aigentry', 'brain', 'profiles'),
    path.join(homeDir, '.aigentry', 'brain', 'search'),
    path.join(homeDir, '.telepty', 'shared'),
    path.join(homeDir, 'Library', 'Application Support', 'aterm'),
  ];

  for (const directory of directories) {
    fs.mkdirSync(directory, { recursive: true });
  }

  const configPath = path.join(homeDir, '.aigentry', 'config', 'aterm.json');
  if (!fs.existsSync(configPath)) {
    const defaultConfig = {
      version: packageJson.version,
      installed_at: new Date().toISOString(),
      platform: `${os.platform()}-${os.arch()}`,
    };
    fs.writeFileSync(`${configPath}`, `${JSON.stringify(defaultConfig, null, 2)}\n`);
  }
}

bootstrapEcosystem();

const platformPackage = resolvePlatformPackage();
if (!platformPackage) {
  console.warn(`[aterm] no native package for ${os.platform()} ${os.arch()}; install skipped`);
  process.exit(0);
}

let platformPackageJsonPath;
try {
  platformPackageJsonPath = require.resolve(`${platformPackage}/package.json`);
} catch (error) {
  console.warn(`[aterm] optional native package not installed: ${platformPackage}`);
  console.warn('[aterm] reinstall after the platform package is available');
  process.exit(0);
}

const platformRoot = path.dirname(platformPackageJsonPath);
const sourceApp = path.join(platformRoot, 'dist', 'aterm.app');
const targetApp = path.join(__dirname, 'dist', 'aterm.app');

if (!fs.existsSync(sourceApp)) {
  console.error(`[aterm] native app bundle missing from ${platformPackage}: ${sourceApp}`);
  process.exit(1);
}

fs.rmSync(path.dirname(targetApp), { recursive: true, force: true });
fs.mkdirSync(path.dirname(targetApp), { recursive: true });
fs.cpSync(sourceApp, targetApp, { recursive: true });

console.log(`[aterm] installed native bundle from ${platformPackage}`);
